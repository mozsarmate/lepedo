/**
 * saveTransfer
 * @param objectrepository
 * saves Transfer data to db (both create and edit)
 * @param id
 * @returns next
 */
module.exports = function (objectrepository, id) {
    return function (req,res,next) {
        return next;
    }
}