/**
 * getTransfers
 * @param objectrepository
 * @returns all Transfer data from db
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}