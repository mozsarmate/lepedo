/**
 * calculateTable
 * @param objectrepository, transfer id
 * transfers summary data to the table on the frontend
 * @returns next
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}