/**
 * calculateStat
 * @param objectrepository, transfer id
 * transfers statistical data to the frontend
 * @returns next
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}