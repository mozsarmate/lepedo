/**
 * getUser
 * @param objectrepository, user id
 * @returns specific user data from db
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}