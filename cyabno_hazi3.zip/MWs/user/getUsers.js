/**
 * getUsers
 * @param objectrepository
 * @returns users data from db
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}