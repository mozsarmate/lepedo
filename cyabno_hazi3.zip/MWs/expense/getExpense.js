/**
 * getExpense
 * @param objectrepository, expense id
 * @returns specific expense data from db
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}