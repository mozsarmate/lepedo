/**
 * getExpenses
 * @param objectrepository
 * @returns all Expense data from db
 */
module.exports = function (objectrepository) {
    return function (req,res,next) {
        return next;
    }
}