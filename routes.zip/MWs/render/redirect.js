/**
 * render
 * @param objectrepository
 * @param link
 * redirects to the given link (not sure this it the best way to do that)
 * @returns next
 */
module.exports = function (objectrepository, link) {
    return function (req,res,next) {
        res.redirect(".."+link);
        return next();
    }
}