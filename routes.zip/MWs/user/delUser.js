/**
 * delUser
 * @param objectrepository, user id
 * @param id
 * deletes specific user record from db
 * @returns next
 */
module.exports = function (objectrepository, id) {
    return function (req,res,next) {
        return next();
    }
}