/**
 * delExpense
 * @param objectrepository, expense id
 * @param id
 * deletes specific expense record from db
 * @returns next
 */
module.exports = function (objectrepository, id) {
    return function (req,res,next) {
        return next();
    }
}