/**
 * saveExpense
 * @param objectrepository
 * @param id
 * saves expense data to db (both create and edit)
 * @returns next
 */
module.exports = function (objectrepository, id) {
    return function (req,res,next) {
        return next();
    }
}