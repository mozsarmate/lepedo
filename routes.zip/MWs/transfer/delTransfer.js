/**
 * delTransfer
 * @param objectrepository, transfer id
 * @param id
 * deletes specific transfer record from db
 * @returns next
 */
module.exports = function (objectrepository, id) {
    return function (req,res,next) {
        return next();
    }
}